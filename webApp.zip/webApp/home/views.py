from django.shortcuts import render
 
from .forms import RegistrationForm
from django.http import HttpResponseRedirect 

def register(request):
    form = RegistrationForm()
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
    
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    
    
    return render(request, 'home/register.html', {'form': form})

def base(request):
    return render(request, 'home/base.html' )
